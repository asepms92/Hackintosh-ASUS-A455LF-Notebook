README.txt

Drag this folder to Desktop folder, and open terminal with commands :

* sudo cp ~/Desktop/BatteryHDAPM/BatteryHDAPM /usr/local/bin
* sudo cp ~/Desktop/BatteryHDAPM/org.qwerty12.BatteryHDAPM.plist /Library/LaunchDaemons
* sudo chmod 755 /usr/local/bin/BatteryHDAPM
* sudo chown root:wheel /usr/local/bin/BatteryHDAPM
* sudo chmod 644 /Library/LaunchDaemons/org.qwerty12.BatteryHDAPM.plist
* sudo chown 0:0 /Library/LaunchDaemons/org.qwerty12.BatteryHDAPM.plist
* sudo chown root:wheel /Library/LaunchDaemons/org.qwerty12.BatteryHDAPM.plist
* sudo launchctl load /Library/LaunchDaemons/org.qwerty12.BatteryHDAPM.plist