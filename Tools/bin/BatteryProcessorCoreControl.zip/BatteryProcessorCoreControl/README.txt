README.txt

Drag this folder to Desktop folder, and open terminal with commands :

* sudo cp ~/Desktop/BatteryProcessorCoreControl/BatteryProcessorCoreControl /usr/local/bin
* sudo cp ~/Desktop/BatteryProcessorCoreControl/org.qwerty12.BatteryProcessorCoreControl.plist /Library/LaunchDaemons
* sudo chmod 755 /usr/local/bin/BatteryProcessorCoreControl
* sudo chown root:wheel /usr/local/bin/BatteryProcessorCoreControl
* sudo chmod 644 /Library/LaunchDaemons/org.qwerty12.BatteryProcessorCoreControl.plist
* sudo chown 0:0 /Library/LaunchDaemons/org.qwerty12.BatteryProcessorCoreControl.plist
* sudo chown root:wheel /Library/LaunchDaemons/org.qwerty12.BatteryProcessorCoreControl.plist
* sudo launchctl load /Library/LaunchDaemons/org.qwerty12.BatteryProcessorCoreControl.plist