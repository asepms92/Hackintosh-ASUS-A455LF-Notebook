#!/bin/bash

echo -e "Installing BatteryProcessorCoreControl Daemon to /usr/local/bin"
sudo cp BatteryProcessorCoreControl /usr/local/bin
sudo chmod 755 /usr/local/bin/BatteryProcessorCoreControl
sudo chown root:wheel /usr/local/bin/BatteryProcessorCoreControl
sudo cp org.qwerty12.BatteryProcessorCoreControl.plist /Library/LaunchDaemons
sudo chmod 644 /Library/LaunchDaemons/org.qwerty12.BatteryProcessorCoreControl.plist
sudo chown root:wheel /Library/LaunchDaemons/org.qwerty12.BatteryProcessorCoreControl.plist
sudo launchctl load /Library/LaunchDaemons/org.qwerty12.BatteryProcessorCoreControl.plist
echo -e "BatteryProcessorCoreControl is installed and loaded. Enjoy!"

exit 0
