/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_2B20EC2A_ACAB_4A98_B34A_B5B9BFB05746
#define _AUTOGENH_2B20EC2A_ACAB_4A98_B34A_B5B9BFB05746

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gEfiFileInfoGuid;
extern GUID gEfiFileSystemInfoGuid;
extern GUID gEfiFileSystemVolumeLabelInfoIdGuid;

// Protocols
extern GUID gEfiFirmwareVolume2ProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
