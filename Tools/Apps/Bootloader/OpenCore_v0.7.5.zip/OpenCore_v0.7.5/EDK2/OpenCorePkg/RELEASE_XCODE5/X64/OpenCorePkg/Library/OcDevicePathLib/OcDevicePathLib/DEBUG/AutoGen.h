/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_BDEBB36A_9261_4908_9E42_FE59E0B43B82
#define _AUTOGENH_BDEBB36A_9261_4908_9E42_FE59E0B43B82

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gEfiPartTypeSystemPartGuid;

// Protocols
extern GUID gEfiDevicePathToTextProtocolGuid;
extern GUID gEfiSimpleFileSystemProtocolGuid;
extern GUID gEfiBlockIoProtocolGuid;
extern GUID gEfiPciIoProtocolGuid;
extern GUID gEfiUsbIoProtocolGuid;
extern GUID gEfiLoadFileProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
