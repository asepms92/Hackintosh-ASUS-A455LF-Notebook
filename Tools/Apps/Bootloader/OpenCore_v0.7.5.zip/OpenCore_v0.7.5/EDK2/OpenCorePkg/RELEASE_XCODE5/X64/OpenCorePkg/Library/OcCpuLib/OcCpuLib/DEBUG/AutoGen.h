/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_5F3FA330_4F32_4AC9_9407_B932CFECFDB2
#define _AUTOGENH_5F3FA330_4F32_4AC9_9407_B932CFECFDB2

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gAppleFsbFrequencyPlatformInfoGuid;
extern GUID gAppleFsbFrequencyListPlatformInfoGuid;
extern GUID gAppleFsbFrequencyPlatformInfoIndexHobGuid;
extern GUID gOcVendorVariableGuid;

// Protocols
extern GUID gApplePlatformInfoDatabaseProtocolGuid;
extern GUID gEfiMpServiceProtocolGuid;
extern GUID gFrameworkEfiMpServiceProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
