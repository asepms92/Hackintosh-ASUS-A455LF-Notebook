/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_509895E3_ABF8_4836_BB0C_919729A8C293
#define _AUTOGENH_509895E3_ABF8_4836_BB0C_919729A8C293

#ifdef __cplusplus
extern "C" {
#endif

#include <PiDxe.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern EFI_GUID gAppleVendorVariableGuid;
extern EFI_GUID gAppleBootVariableGuid;

// Protocols
extern EFI_GUID gAppleFramebufferInfoProtocolGuid;
extern EFI_GUID gAppleEg2InfoProtocolGuid;
extern EFI_GUID gEfiConsoleControlProtocolGuid;
extern EFI_GUID gEfiGraphicsOutputProtocolGuid;
extern EFI_GUID gEfiSimpleTextOutProtocolGuid;
extern EFI_GUID gEfiUgaDrawProtocolGuid;
extern EFI_GUID gOcForceResolutionProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
