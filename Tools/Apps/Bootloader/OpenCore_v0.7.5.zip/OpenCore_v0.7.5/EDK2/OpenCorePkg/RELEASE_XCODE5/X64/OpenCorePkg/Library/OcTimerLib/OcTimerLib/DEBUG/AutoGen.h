/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_8BF2026F_C0BB_4A5D_A7DB_395DAB5A73E7
#define _AUTOGENH_8BF2026F_C0BB_4A5D_A7DB_395DAB5A73E7

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

RETURN_STATUS
EFIAPI
OcTimerLibConstructor (
  VOID
  );


#ifdef __cplusplus
}
#endif

#endif
