/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_A28FEC6F_DD5C_4D8D_9351_50D9A2047634
#define _AUTOGENH_A28FEC6F_DD5C_4D8D_9351_50D9A2047634

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gAppleApfsContainerInfoGuid;
extern GUID gAppleApfsVolumeInfoGuid;
extern GUID gAppleBlessedSystemFileInfoGuid;
extern GUID gAppleBlessedSystemFolderInfoGuid;
extern GUID gAppleBlessedOsxFolderInfoGuid;
extern GUID gEfiFileInfoGuid;
extern GUID gEfiGlobalVariableGuid;
extern GUID gEfiPartTypeSystemPartGuid;
extern GUID gAppleApfsPartitionTypeGuid;
extern GUID gAppleBootVariableGuid;
extern GUID gAppleHfsPartitionTypeGuid;
extern GUID gAppleHfsBootPartitionTypeGuid;
extern GUID gAppleLegacyLoadAppFileGuid;
extern GUID gAppleVendorVariableGuid;
extern GUID gAppleCoreStorageVariableGuid;
extern GUID gAppleTamperResistantBootVariableGuid;
extern GUID gAppleWirelessNetworkVariableGuid;
extern GUID gApplePersonalizationVariableGuid;
extern GUID gAppleNetbootVariableGuid;
extern GUID gAppleSecureBootVariableGuid;
extern GUID gAppleTamperResistantBootSecureVariableGuid;
extern GUID gAppleTamperResistantBootEfiUserVariableGuid;
extern GUID gEfiPartTypeUnusedGuid;
extern GUID gOcVendorVariableGuid;
extern GUID gOcReadOnlyVariableGuid;
extern GUID gOcWriteOnlyVariableGuid;
extern GUID gAppleBootPickerFileGuid;
extern GUID gMicrosoftVariableGuid;

// Protocols
extern GUID gAppleBootPolicyProtocolGuid;
extern GUID gAppleKeyMapAggregatorProtocolGuid;
extern GUID gEfiSimpleFileSystemProtocolGuid;
extern GUID gEfiLoadedImageProtocolGuid;
extern GUID gEfiUsbIoProtocolGuid;
extern GUID gOcFirmwareRuntimeProtocolGuid;
extern GUID gOcAudioProtocolGuid;
extern GUID gAppleBeepGenProtocolGuid;
extern GUID gOcBootEntryProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
