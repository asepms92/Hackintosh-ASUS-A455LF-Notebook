/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_9854233D_BBFE_435A_A358_74C0C84A7A80
#define _AUTOGENH_9854233D_BBFE_435A_A358_74C0C84A7A80

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>
#include <Library/PcdLib.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gAppleBootVariableGuid;
extern GUID gAppleVendorVariableGuid;
extern GUID gOpenCorePkgTokenSpaceGuid;

// Protocols
extern GUID gEfiDevicePathPropertyDatabaseProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

// PCD definitions
#define _PCD_TOKEN_PcdEnableAppleThunderboltSync  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdEnableAppleThunderboltSync;
#define _PCD_GET_MODE_BOOL_PcdEnableAppleThunderboltSync  _gPcd_FixedAtBuild_PcdEnableAppleThunderboltSync
//#define _PCD_SET_MODE_BOOL_PcdEnableAppleThunderboltSync  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_TOKEN_PcNvramInitDevicePropertyDatabase  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcNvramInitDevicePropertyDatabase;
#define _PCD_GET_MODE_BOOL_PcNvramInitDevicePropertyDatabase  _gPcd_FixedAtBuild_PcNvramInitDevicePropertyDatabase
//#define _PCD_SET_MODE_BOOL_PcNvramInitDevicePropertyDatabase  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD


#ifdef __cplusplus
}
#endif

#endif
