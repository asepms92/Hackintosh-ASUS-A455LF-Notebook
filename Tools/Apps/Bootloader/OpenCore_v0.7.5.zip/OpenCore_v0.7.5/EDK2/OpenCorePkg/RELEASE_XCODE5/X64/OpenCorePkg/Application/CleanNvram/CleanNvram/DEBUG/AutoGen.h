/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_09BD751B_774E_4F54_A339_D9D6D8274BD1
#define _AUTOGENH_09BD751B_774E_4F54_A339_D9D6D8274BD1

#ifdef __cplusplus
extern "C" {
#endif

#include <Uefi.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;

#define EFI_CALLER_ID_GUID \
  {0x09BD751B, 0x774E, 0x4F54, {0xA3, 0x39, 0xD9, 0xD6, 0xD8, 0x27, 0x4B, 0xD1}}
#define EDKII_DSC_PLATFORM_GUID \
  {0xC46F121D, 0xABC6, 0x42A3, {0xA2, 0x41, 0x91, 0xB0, 0x92, 0x24, 0xC3, 0x57}}

// Guids
extern EFI_GUID gOcVendorVariableGuid;
extern EFI_GUID gEfiMdePkgTokenSpaceGuid;
extern EFI_GUID gEfiPartTypeSystemPartGuid;
extern EFI_GUID gEfiFileInfoGuid;
extern EFI_GUID gEfiFileSystemInfoGuid;
extern EFI_GUID gEfiFileSystemVolumeLabelInfoIdGuid;
extern EFI_GUID gEfiProcessorSubClassGuid;
extern EFI_GUID gEfiMiscSubClassGuid;
extern EFI_GUID gApplePlatformProducerNameGuid;
extern EFI_GUID gAppleFsbFrequencyPlatformInfoGuid;
extern EFI_GUID gAppleFsbFrequencyListPlatformInfoGuid;
extern EFI_GUID gAppleFsbFrequencyPlatformInfoIndexHobGuid;
extern EFI_GUID gEfiVTUTF8Guid;
extern EFI_GUID gEfiVT100Guid;
extern EFI_GUID gEfiVT100PlusGuid;
extern EFI_GUID gEfiPcAnsiGuid;
extern EFI_GUID gEfiUartDevicePathGuid;
extern EFI_GUID gEfiSasDevicePathGuid;
extern EFI_GUID gEfiVirtualDiskGuid;
extern EFI_GUID gEfiVirtualCdGuid;
extern EFI_GUID gEfiPersistentVirtualDiskGuid;
extern EFI_GUID gEfiPersistentVirtualCdGuid;
extern EFI_GUID gEfiEventReadyToBootGuid;
extern EFI_GUID gEfiEventLegacyBootGuid;
extern EFI_GUID gEfiGlobalVariableGuid;
extern EFI_GUID gEfiAcpi20TableGuid;
extern EFI_GUID gEfiAcpi10TableGuid;
extern EFI_GUID gEfiHobListGuid;
extern EFI_GUID gEfiMdeModulePkgTokenSpaceGuid;
extern EFI_GUID gEfiMemoryAttributesTableGuid;
extern EFI_GUID gOpenCorePkgTokenSpaceGuid;
extern EFI_GUID gUefiCpuPkgTokenSpaceGuid;
extern EFI_GUID gEfiEventExitBootServicesGuid;
extern EFI_GUID gEfiEventVirtualAddressChangeGuid;
extern EFI_GUID gAppleEfiCertificateGuid;
extern EFI_GUID gEfiCertTypeRsa2048Sha256Guid;
extern EFI_GUID gAppleVendorVariableGuid;
extern EFI_GUID gAppleBootVariableGuid;
extern EFI_GUID gAppleSecureBootVariableGuid;
extern EFI_GUID gAppleApfsContainerInfoGuid;
extern EFI_GUID gAppleApfsVolumeInfoGuid;
extern EFI_GUID gAppleBlessedSystemFileInfoGuid;
extern EFI_GUID gAppleBlessedSystemFolderInfoGuid;
extern EFI_GUID gAppleBlessedOsxFolderInfoGuid;
extern EFI_GUID gAppleApfsPartitionTypeGuid;
extern EFI_GUID gAppleHfsPartitionTypeGuid;
extern EFI_GUID gAppleHfsBootPartitionTypeGuid;
extern EFI_GUID gAppleLegacyLoadAppFileGuid;
extern EFI_GUID gAppleCoreStorageVariableGuid;
extern EFI_GUID gAppleTamperResistantBootVariableGuid;
extern EFI_GUID gAppleWirelessNetworkVariableGuid;
extern EFI_GUID gApplePersonalizationVariableGuid;
extern EFI_GUID gAppleNetbootVariableGuid;
extern EFI_GUID gAppleTamperResistantBootSecureVariableGuid;
extern EFI_GUID gAppleTamperResistantBootEfiUserVariableGuid;
extern EFI_GUID gEfiPartTypeUnusedGuid;
extern EFI_GUID gOcReadOnlyVariableGuid;
extern EFI_GUID gOcWriteOnlyVariableGuid;
extern EFI_GUID gAppleBootPickerFileGuid;
extern EFI_GUID gMicrosoftVariableGuid;

// Protocols
extern EFI_GUID gEfiUnicodeCollation2ProtocolGuid;
extern EFI_GUID gEfiDevicePathProtocolGuid;
extern EFI_GUID gEfiDevicePathToTextProtocolGuid;
extern EFI_GUID gEfiSimpleFileSystemProtocolGuid;
extern EFI_GUID gEfiBlockIoProtocolGuid;
extern EFI_GUID gEfiPciIoProtocolGuid;
extern EFI_GUID gEfiUsbIoProtocolGuid;
extern EFI_GUID gEfiLoadFileProtocolGuid;
extern EFI_GUID gEfiFirmwareVolumeProtocolGuid;
extern EFI_GUID gEfiFirmwareVolume2ProtocolGuid;
extern EFI_GUID gEfiBlockIo2ProtocolGuid;
extern EFI_GUID gOcBootstrapProtocolGuid;
extern EFI_GUID gEfiShellParametersProtocolGuid;
extern EFI_GUID gEfiLoadedImageProtocolGuid;
extern EFI_GUID gEfiDataHubProtocolGuid;
extern EFI_GUID gApplePlatformInfoDatabaseProtocolGuid;
extern EFI_GUID gEfiMpServiceProtocolGuid;
extern EFI_GUID gFrameworkEfiMpServiceProtocolGuid;
extern EFI_GUID gEfiDebugPortProtocolGuid;
extern EFI_GUID gOcLogProtocolGuid;
extern EFI_GUID gAppleDebugLogProtocolGuid;
extern EFI_GUID gEfiDriverBindingProtocolGuid;
extern EFI_GUID gEfiSimpleTextOutProtocolGuid;
extern EFI_GUID gEfiGraphicsOutputProtocolGuid;
extern EFI_GUID gEfiHiiFontProtocolGuid;
extern EFI_GUID gEfiUgaDrawProtocolGuid;
extern EFI_GUID gEfiComponentNameProtocolGuid;
extern EFI_GUID gEfiComponentName2ProtocolGuid;
extern EFI_GUID gEfiDriverConfigurationProtocolGuid;
extern EFI_GUID gEfiDriverConfiguration2ProtocolGuid;
extern EFI_GUID gEfiDriverDiagnosticsProtocolGuid;
extern EFI_GUID gEfiDriverDiagnostics2ProtocolGuid;
extern EFI_GUID gEfiLegacyRegionProtocolGuid;
extern EFI_GUID gEfiLegacyRegion2ProtocolGuid;
extern EFI_GUID gEfiDecompressProtocolGuid;
extern EFI_GUID gEfiPlatformDriverOverrideProtocolGuid;
extern EFI_GUID gAppleFramebufferInfoProtocolGuid;
extern EFI_GUID gAppleEg2InfoProtocolGuid;
extern EFI_GUID gEfiConsoleControlProtocolGuid;
extern EFI_GUID gOcForceResolutionProtocolGuid;
extern EFI_GUID gAppleEventProtocolGuid;
extern EFI_GUID gAppleRtcRamProtocolGuid;
extern EFI_GUID gAppleSecureBootProtocolGuid;
extern EFI_GUID gAppleImg4VerificationProtocolGuid;
extern EFI_GUID gAppleKeyMapDatabaseProtocolGuid;
extern EFI_GUID gAppleKeyMapAggregatorProtocolGuid;
extern EFI_GUID gAppleRamDiskProtocolGuid;
extern EFI_GUID gAppleDiskImageProtocolGuid;
extern EFI_GUID gAppleBootPolicyProtocolGuid;
extern EFI_GUID gApfsEfiBootRecordInfoProtocolGuid;
extern EFI_GUID gApfsUnsupportedBdsProtocolGuid;
extern EFI_GUID gEfiPartitionInfoProtocolGuid;
extern EFI_GUID gOcFirmwareRuntimeProtocolGuid;
extern EFI_GUID gOcAudioProtocolGuid;
extern EFI_GUID gAppleBeepGenProtocolGuid;
extern EFI_GUID gOcBootEntryProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

// Definition of PCDs used in libraries is in AutoGen.c


EFI_STATUS
EFIAPI
UefiMain (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  );





#ifdef __cplusplus
}
#endif

#endif
