/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_F8E071ED_3EAB_46C6_9C50_B99B6B3915FF
#define _AUTOGENH_F8E071ED_3EAB_46C6_9C50_B99B6B3915FF

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Protocols
extern GUID gEfiDevicePathProtocolGuid;
extern GUID gEfiBlockIoProtocolGuid;
extern GUID gAppleRamDiskProtocolGuid;
extern GUID gAppleDiskImageProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
