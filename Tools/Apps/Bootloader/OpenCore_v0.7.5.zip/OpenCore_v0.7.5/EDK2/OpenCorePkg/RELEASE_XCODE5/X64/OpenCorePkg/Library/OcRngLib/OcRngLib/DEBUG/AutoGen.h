/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_416BA864_86D7_4AB5_A508_3B91DC52CFC9
#define _AUTOGENH_416BA864_86D7_4AB5_A508_3B91DC52CFC9

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

RETURN_STATUS
EFIAPI
OcRngLibConstructor (
  VOID
  );


#ifdef __cplusplus
}
#endif

#endif
