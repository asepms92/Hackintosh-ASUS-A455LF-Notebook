/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_93D299BF_BF18_43E5_983A_1AA8694497FF
#define _AUTOGENH_93D299BF_BF18_43E5_983A_1AA8694497FF

#ifdef __cplusplus
extern "C" {
#endif

#include <PiDxe.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern EFI_GUID gAppleImageListGuid;
extern EFI_GUID gAppleArrowCursorImageGuid;
extern EFI_GUID gAppleArrowCursor2xImageGuid;

// Protocols
extern EFI_GUID gEfiFirmwareVolumeProtocolGuid;
extern EFI_GUID gEfiFirmwareVolume2ProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
