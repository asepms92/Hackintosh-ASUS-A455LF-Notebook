/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_556f5d10_7309_4af4_b80a_8196bd60946e
#define _AUTOGENH_556f5d10_7309_4af4_b80a_8196bd60946e

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>
#include <Library/PcdLib.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gOpenCorePkgTokenSpaceGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

// PCD definitions
#define _PCD_TOKEN_PcdImageLoaderRtRelocAllowTargetMismatch  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdImageLoaderRtRelocAllowTargetMismatch;
#define _PCD_GET_MODE_BOOL_PcdImageLoaderRtRelocAllowTargetMismatch  _gPcd_FixedAtBuild_PcdImageLoaderRtRelocAllowTargetMismatch
//#define _PCD_SET_MODE_BOOL_PcdImageLoaderRtRelocAllowTargetMismatch  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdImageLoaderRtRelocAllowTargetMismatch 0
#define _PCD_SIZE_PcdImageLoaderRtRelocAllowTargetMismatch 1
#define _PCD_GET_MODE_SIZE_PcdImageLoaderRtRelocAllowTargetMismatch _PCD_SIZE_PcdImageLoaderRtRelocAllowTargetMismatch
#define _PCD_TOKEN_PcdImageLoaderHashProhibitOverlap  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdImageLoaderHashProhibitOverlap;
#define _PCD_GET_MODE_BOOL_PcdImageLoaderHashProhibitOverlap  _gPcd_FixedAtBuild_PcdImageLoaderHashProhibitOverlap
//#define _PCD_SET_MODE_BOOL_PcdImageLoaderHashProhibitOverlap  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdImageLoaderHashProhibitOverlap 1
#define _PCD_SIZE_PcdImageLoaderHashProhibitOverlap 1
#define _PCD_GET_MODE_SIZE_PcdImageLoaderHashProhibitOverlap _PCD_SIZE_PcdImageLoaderHashProhibitOverlap
#define _PCD_TOKEN_PcdImageLoaderLoadHeader  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdImageLoaderLoadHeader;
#define _PCD_GET_MODE_BOOL_PcdImageLoaderLoadHeader  _gPcd_FixedAtBuild_PcdImageLoaderLoadHeader
//#define _PCD_SET_MODE_BOOL_PcdImageLoaderLoadHeader  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdImageLoaderLoadHeader 1
#define _PCD_SIZE_PcdImageLoaderLoadHeader 1
#define _PCD_GET_MODE_SIZE_PcdImageLoaderLoadHeader _PCD_SIZE_PcdImageLoaderLoadHeader
#define _PCD_TOKEN_PcdImageLoaderSupportArmThumb  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdImageLoaderSupportArmThumb;
#define _PCD_GET_MODE_BOOL_PcdImageLoaderSupportArmThumb  _gPcd_FixedAtBuild_PcdImageLoaderSupportArmThumb
//#define _PCD_SET_MODE_BOOL_PcdImageLoaderSupportArmThumb  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdImageLoaderSupportArmThumb 0
#define _PCD_SIZE_PcdImageLoaderSupportArmThumb 1
#define _PCD_GET_MODE_SIZE_PcdImageLoaderSupportArmThumb _PCD_SIZE_PcdImageLoaderSupportArmThumb
#define _PCD_TOKEN_PcdImageLoaderForceLoadDebug  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdImageLoaderForceLoadDebug;
#define _PCD_GET_MODE_BOOL_PcdImageLoaderForceLoadDebug  _gPcd_FixedAtBuild_PcdImageLoaderForceLoadDebug
//#define _PCD_SET_MODE_BOOL_PcdImageLoaderForceLoadDebug  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdImageLoaderForceLoadDebug 0
#define _PCD_SIZE_PcdImageLoaderForceLoadDebug 1
#define _PCD_GET_MODE_SIZE_PcdImageLoaderForceLoadDebug _PCD_SIZE_PcdImageLoaderForceLoadDebug
#define _PCD_TOKEN_PcdImageLoaderTolerantLoad  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdImageLoaderTolerantLoad;
#define _PCD_GET_MODE_BOOL_PcdImageLoaderTolerantLoad  _gPcd_FixedAtBuild_PcdImageLoaderTolerantLoad
//#define _PCD_SET_MODE_BOOL_PcdImageLoaderTolerantLoad  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdImageLoaderTolerantLoad 1
#define _PCD_SIZE_PcdImageLoaderTolerantLoad 1
#define _PCD_GET_MODE_SIZE_PcdImageLoaderTolerantLoad _PCD_SIZE_PcdImageLoaderTolerantLoad
#define _PCD_TOKEN_PcdImageLoaderSupportDebug  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdImageLoaderSupportDebug;
#define _PCD_GET_MODE_BOOL_PcdImageLoaderSupportDebug  _gPcd_FixedAtBuild_PcdImageLoaderSupportDebug
//#define _PCD_SET_MODE_BOOL_PcdImageLoaderSupportDebug  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdImageLoaderSupportDebug 0
#define _PCD_SIZE_PcdImageLoaderSupportDebug 1
#define _PCD_GET_MODE_SIZE_PcdImageLoaderSupportDebug _PCD_SIZE_PcdImageLoaderSupportDebug


#ifdef __cplusplus
}
#endif

#endif
