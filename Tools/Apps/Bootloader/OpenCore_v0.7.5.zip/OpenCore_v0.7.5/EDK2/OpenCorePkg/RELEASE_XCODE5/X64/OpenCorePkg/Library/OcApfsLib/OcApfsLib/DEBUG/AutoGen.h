/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_D7CE048F_C527_45D2_9B77_7E49A50DC434
#define _AUTOGENH_D7CE048F_C527_45D2_9B77_7E49A50DC434

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gAppleApfsPartitionTypeGuid;

// Protocols
extern GUID gEfiBlockIoProtocolGuid;
extern GUID gEfiBlockIo2ProtocolGuid;
extern GUID gApfsEfiBootRecordInfoProtocolGuid;
extern GUID gApfsUnsupportedBdsProtocolGuid;
extern GUID gEfiLoadedImageProtocolGuid;
extern GUID gEfiDevicePathProtocolGuid;
extern GUID gEfiPartitionInfoProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
