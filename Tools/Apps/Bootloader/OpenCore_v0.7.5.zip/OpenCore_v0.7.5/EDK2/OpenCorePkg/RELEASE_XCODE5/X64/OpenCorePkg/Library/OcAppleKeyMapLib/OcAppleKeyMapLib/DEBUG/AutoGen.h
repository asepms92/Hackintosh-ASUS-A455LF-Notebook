/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_3A5CA054_2A65_4A00_AE58_B61BAFD6CF9A
#define _AUTOGENH_3A5CA054_2A65_4A00_AE58_B61BAFD6CF9A

#ifdef __cplusplus
extern "C" {
#endif

#include <PiDxe.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Protocols
extern EFI_GUID gAppleKeyMapDatabaseProtocolGuid;
extern EFI_GUID gAppleKeyMapAggregatorProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
