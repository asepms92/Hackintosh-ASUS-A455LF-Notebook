/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_987B4FC6_929A_4F34_9C1B_1876484C92FE
#define _AUTOGENH_987B4FC6_929A_4F34_9C1B_1876484C92FE

#ifdef __cplusplus
extern "C" {
#endif

#include <PiDxe.h>
#include <Library/PcdLib.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern EFI_GUID gOpenCorePkgTokenSpaceGuid;

// Protocols
extern EFI_GUID gEfiConsoleControlProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

// PCD definitions
#define _PCD_TOKEN_PcdConsoleControlEntryMode  0U
extern const UINT8 _gPcd_FixedAtBuild_PcdConsoleControlEntryMode;
#define _PCD_GET_MODE_8_PcdConsoleControlEntryMode  _gPcd_FixedAtBuild_PcdConsoleControlEntryMode
//#define _PCD_SET_MODE_8_PcdConsoleControlEntryMode  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdConsoleControlEntryMode 0
#define _PCD_SIZE_PcdConsoleControlEntryMode 1
#define _PCD_GET_MODE_SIZE_PcdConsoleControlEntryMode _PCD_SIZE_PcdConsoleControlEntryMode

EFI_STATUS
EFIAPI
OcConsoleControlEntryModeConstructor (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  );


#ifdef __cplusplus
}
#endif

#endif
