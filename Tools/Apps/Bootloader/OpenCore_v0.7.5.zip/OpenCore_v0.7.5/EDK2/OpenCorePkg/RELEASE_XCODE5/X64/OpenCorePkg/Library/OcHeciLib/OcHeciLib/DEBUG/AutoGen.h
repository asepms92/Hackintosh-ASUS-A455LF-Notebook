/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_1F1ECC50_2F1B_4888_AF74_686D8D7FC0E5
#define _AUTOGENH_1F1ECC50_2F1B_4888_AF74_686D8D7FC0E5

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gOcReadOnlyVariableGuid;
extern GUID gOcWriteOnlyVariableGuid;

// Protocols
extern GUID gEfiHeciProtocolGuid;
extern GUID gEfiHeci2ProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
