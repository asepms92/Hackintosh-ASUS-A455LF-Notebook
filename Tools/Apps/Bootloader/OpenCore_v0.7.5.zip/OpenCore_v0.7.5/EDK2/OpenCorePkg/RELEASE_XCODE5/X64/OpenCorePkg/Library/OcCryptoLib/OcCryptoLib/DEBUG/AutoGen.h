/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_56C05E0A_52BB_4B16_B472_6A816E82E5AD
#define _AUTOGENH_56C05E0A_52BB_4B16_B472_6A816E82E5AD

#ifdef __cplusplus
extern "C" {
#endif

#include <PiDxe.h>
#include <Library/PcdLib.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern EFI_GUID gOpenCorePkgTokenSpaceGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

// PCD definitions
#define _PCD_TOKEN_PcdOcCryptoAllowedRsaModuli  0U
extern const UINT16 _gPcd_FixedAtBuild_PcdOcCryptoAllowedRsaModuli;
#define _PCD_GET_MODE_16_PcdOcCryptoAllowedRsaModuli  _gPcd_FixedAtBuild_PcdOcCryptoAllowedRsaModuli
//#define _PCD_SET_MODE_16_PcdOcCryptoAllowedRsaModuli  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdOcCryptoAllowedRsaModuli 0x300
#define _PCD_SIZE_PcdOcCryptoAllowedRsaModuli 2
#define _PCD_GET_MODE_SIZE_PcdOcCryptoAllowedRsaModuli _PCD_SIZE_PcdOcCryptoAllowedRsaModuli
#define _PCD_TOKEN_PcdOcCryptoAllowedSigHashTypes  0U
extern const UINT16 _gPcd_FixedAtBuild_PcdOcCryptoAllowedSigHashTypes;
#define _PCD_GET_MODE_16_PcdOcCryptoAllowedSigHashTypes  _gPcd_FixedAtBuild_PcdOcCryptoAllowedSigHashTypes
//#define _PCD_SET_MODE_16_PcdOcCryptoAllowedSigHashTypes  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdOcCryptoAllowedSigHashTypes 0x07
#define _PCD_SIZE_PcdOcCryptoAllowedSigHashTypes 2
#define _PCD_GET_MODE_SIZE_PcdOcCryptoAllowedSigHashTypes _PCD_SIZE_PcdOcCryptoAllowedSigHashTypes


#ifdef __cplusplus
}
#endif

#endif
