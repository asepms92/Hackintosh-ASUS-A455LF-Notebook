/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_F5A0BBDD_A4D9_4E55_82C1_A239DF146911
#define _AUTOGENH_F5A0BBDD_A4D9_4E55_82C1_A239DF146911

#ifdef __cplusplus
extern "C" {
#endif

#include <PiDxe.h>
#include <Library/PcdLib.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern EFI_GUID gEfiHiiKeyBoardLayoutGuid;
extern EFI_GUID gEfiHiiImageDecoderNameJpegGuid;
extern EFI_GUID gEfiHiiImageDecoderNamePngGuid;
extern EFI_GUID gEdkiiIfrBitVarstoreGuid;
extern EFI_GUID gEfiMdeModulePkgTokenSpaceGuid;
extern EFI_GUID gEfiMdePkgTokenSpaceGuid;

// Protocols
extern EFI_GUID gEfiDevicePathProtocolGuid;
extern EFI_GUID gEfiHiiStringProtocolGuid;
extern EFI_GUID gEfiHiiImageProtocolGuid;
extern EFI_GUID gEfiHiiImageExProtocolGuid;
extern EFI_GUID gEfiHiiImageDecoderProtocolGuid;
extern EFI_GUID gEfiHiiConfigRoutingProtocolGuid;
extern EFI_GUID gEfiHiiDatabaseProtocolGuid;
extern EFI_GUID gEfiHiiFontProtocolGuid;
extern EFI_GUID gEfiHiiConfigAccessProtocolGuid;
extern EFI_GUID gEfiConfigKeywordHandlerProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

// Definition of PCD Token Space GUIDs used in this module

extern EFI_GUID gEfiMdeModulePkgTokenSpaceGuid;

// PCD definitions
#define _PCD_TOKEN_PcdSupportHiiImageProtocol  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdSupportHiiImageProtocol;
#define _PCD_GET_MODE_BOOL_PcdSupportHiiImageProtocol  _gPcd_FixedAtBuild_PcdSupportHiiImageProtocol
//#define _PCD_SET_MODE_BOOL_PcdSupportHiiImageProtocol  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_TOKEN_PcdHiiOsRuntimeSupport  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdHiiOsRuntimeSupport;
#define _PCD_GET_MODE_BOOL_PcdHiiOsRuntimeSupport  _gPcd_FixedAtBuild_PcdHiiOsRuntimeSupport
//#define _PCD_SET_MODE_BOOL_PcdHiiOsRuntimeSupport  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_TOKEN_PcdUefiVariableDefaultPlatformLang  0U
extern const UINT8 _gPcd_FixedAtBuild_PcdUefiVariableDefaultPlatformLang[];
#define _PCD_GET_MODE_PTR_PcdUefiVariableDefaultPlatformLang  _gPcd_FixedAtBuild_PcdUefiVariableDefaultPlatformLang
//#define _PCD_SET_MODE_PTR_PcdUefiVariableDefaultPlatformLang  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdUefiVariableDefaultPlatformLang _gPcd_FixedAtBuild_PcdUefiVariableDefaultPlatformLang
#define _PCD_SIZE_PcdUefiVariableDefaultPlatformLang 6
#define _PCD_GET_MODE_SIZE_PcdUefiVariableDefaultPlatformLang _PCD_SIZE_PcdUefiVariableDefaultPlatformLang

#define _PCD_TOKEN_gEfiMdeModulePkgTokenSpaceGuid_PcdNvStoreDefaultValueBuffer  196613U
#define _PCD_TOKEN_PcdNvStoreDefaultValueBuffer  _PCD_TOKEN_gEfiMdeModulePkgTokenSpaceGuid_PcdNvStoreDefaultValueBuffer
#define _PCD_GET_MODE_PTR_PcdNvStoreDefaultValueBuffer  LibPcdGetExPtr(&gEfiMdeModulePkgTokenSpaceGuid, _PCD_TOKEN_PcdNvStoreDefaultValueBuffer)
#define _PCD_GET_MODE_SIZE_PcdNvStoreDefaultValueBuffer LibPcdGetExSize(&gEfiMdeModulePkgTokenSpaceGuid, _PCD_TOKEN_PcdNvStoreDefaultValueBuffer)
#define _PCD_SET_MODE_PTR_PcdNvStoreDefaultValueBuffer(SizeOfBuffer, Buffer)  LibPcdSetExPtr(&gEfiMdeModulePkgTokenSpaceGuid, _PCD_TOKEN_PcdNvStoreDefaultValueBuffer, (SizeOfBuffer), (Buffer))
#define _PCD_SET_MODE_PTR_S_PcdNvStoreDefaultValueBuffer(SizeOfBuffer, Buffer)  LibPcdSetExPtrS(&gEfiMdeModulePkgTokenSpaceGuid, _PCD_TOKEN_PcdNvStoreDefaultValueBuffer, (SizeOfBuffer), (Buffer))

#define COMPAREGUID(Guid1, Guid2) (BOOLEAN)(*(CONST UINT64*)Guid1 == *(CONST UINT64*)Guid2 && *((CONST UINT64*)Guid1 + 1) == *((CONST UINT64*)Guid2 + 1))

#define __PCD_PcdNvStoreDefaultValueBuffer_ADDR_CMP(GuidPtr)  (\
  (GuidPtr == &gEfiMdeModulePkgTokenSpaceGuid) ? _PCD_TOKEN_gEfiMdeModulePkgTokenSpaceGuid_PcdNvStoreDefaultValueBuffer:0 \
  )

#define __PCD_PcdNvStoreDefaultValueBuffer_VAL_CMP(GuidPtr)  (\
  (GuidPtr == NULL) ? 0:\
  COMPAREGUID (GuidPtr, &gEfiMdeModulePkgTokenSpaceGuid) ? _PCD_TOKEN_gEfiMdeModulePkgTokenSpaceGuid_PcdNvStoreDefaultValueBuffer:0 \
  )
#define _PCD_TOKEN_EX_PcdNvStoreDefaultValueBuffer(GuidPtr)   __PCD_PcdNvStoreDefaultValueBuffer_ADDR_CMP(GuidPtr) ? __PCD_PcdNvStoreDefaultValueBuffer_ADDR_CMP(GuidPtr) : __PCD_PcdNvStoreDefaultValueBuffer_VAL_CMP(GuidPtr)  

EFI_STATUS
EFIAPI
OcHiiDatabaseLocalLibConstructor (
  IN EFI_HANDLE        ImageHandle,
  IN EFI_SYSTEM_TABLE  *SystemTable
  );


#ifdef __cplusplus
}
#endif

#endif
