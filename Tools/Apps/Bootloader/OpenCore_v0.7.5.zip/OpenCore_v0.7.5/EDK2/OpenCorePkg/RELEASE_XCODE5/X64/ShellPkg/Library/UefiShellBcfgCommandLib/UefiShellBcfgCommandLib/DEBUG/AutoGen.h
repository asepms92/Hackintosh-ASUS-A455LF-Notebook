/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_F6A3BF5D_4095_4E4F_9670_408770C2DBDF
#define _AUTOGENH_F6A3BF5D_4095_4E4F_9670_408770C2DBDF

#ifdef __cplusplus
extern "C" {
#endif

#include <Uefi.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern EFI_GUID gShellBcfgHiiGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];
#include "UefiShellBcfgCommandLibStrDefs.h"


#ifdef __cplusplus
}
#endif

#endif
