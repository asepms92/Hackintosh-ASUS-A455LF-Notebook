/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_EADEF108_EFA4_4425_A2C3_4682118B888B
#define _AUTOGENH_EADEF108_EFA4_4425_A2C3_4682118B888B

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gEfiMemoryAttributesTableGuid;

// Protocols
extern GUID gEfiLegacyRegionProtocolGuid;
extern GUID gEfiLegacyRegion2ProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
