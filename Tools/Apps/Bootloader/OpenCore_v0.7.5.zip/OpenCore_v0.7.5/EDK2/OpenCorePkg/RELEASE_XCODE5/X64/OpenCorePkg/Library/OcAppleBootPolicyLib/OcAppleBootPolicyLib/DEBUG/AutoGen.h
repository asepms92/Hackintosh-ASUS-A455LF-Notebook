/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_330E9083_C008_4030_AA86_ECF1FBAE824D
#define _AUTOGENH_330E9083_C008_4030_AA86_ECF1FBAE824D

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gAppleApfsContainerInfoGuid;
extern GUID gAppleApfsVolumeInfoGuid;
extern GUID gAppleBlessedSystemFileInfoGuid;
extern GUID gAppleBlessedSystemFolderInfoGuid;
extern GUID gAppleBlessedOsxFolderInfoGuid;
extern GUID gEfiFileInfoGuid;

// Protocols
extern GUID gAppleBootPolicyProtocolGuid;
extern GUID gEfiSimpleFileSystemProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
