/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_F39652DB_3D7E_49CC_A66B_E99AC74F5D37
#define _AUTOGENH_F39652DB_3D7E_49CC_A66B_E99AC74F5D37

#ifdef __cplusplus
extern "C" {
#endif

#include <Uefi.h>
#include <Library/PcdLib.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern EFI_GUID gEfiHiiKeyBoardLayoutGuid;
extern EFI_GUID gUsbKeyboardLayoutPackageGuid;
extern EFI_GUID gUsbKeyboardLayoutKeyGuid;
extern EFI_GUID gAppleKeyboardPlatformInfoGuid;

// Protocols
extern EFI_GUID gEfiUsbIoProtocolGuid;
extern EFI_GUID gEfiDevicePathProtocolGuid;
extern EFI_GUID gEfiSimpleTextInProtocolGuid;
extern EFI_GUID gEfiSimpleTextInputExProtocolGuid;
extern EFI_GUID gEfiSimplePointerProtocolGuid;
extern EFI_GUID gEfiTimerArchProtocolGuid;
extern EFI_GUID gEfiHiiDatabaseProtocolGuid;
extern EFI_GUID gAppleKeyMapDatabaseProtocolGuid;
extern EFI_GUID gApplePlatformInfoDatabaseProtocolGuid;
extern EFI_GUID gEfiKeyboardInfoProtocolGuid;
extern EFI_GUID gAmiEfiPointerProtocolGuid;
extern EFI_GUID gAmiEfiKeycodeProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
