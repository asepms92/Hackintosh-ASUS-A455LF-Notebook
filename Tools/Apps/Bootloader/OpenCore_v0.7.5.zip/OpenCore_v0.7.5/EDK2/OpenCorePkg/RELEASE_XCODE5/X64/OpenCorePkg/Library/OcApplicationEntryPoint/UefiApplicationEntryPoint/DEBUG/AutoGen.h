/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_F2C556D6_C7FA_4930_8F04_5953D9E7A98B
#define _AUTOGENH_F2C556D6_C7FA_4930_8F04_5953D9E7A98B

#ifdef __cplusplus
extern "C" {
#endif

#include <Uefi.h>
#include <Library/PcdLib.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern EFI_GUID gEfiMdePkgTokenSpaceGuid;
extern EFI_GUID gOpenCorePkgTokenSpaceGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];

// PCD definitions
#define _PCD_TOKEN_PcdDebugPropertyMask  0U
extern const UINT8 _gPcd_FixedAtBuild_PcdDebugPropertyMask;
#define _PCD_GET_MODE_8_PcdDebugPropertyMask  _gPcd_FixedAtBuild_PcdDebugPropertyMask
//#define _PCD_SET_MODE_8_PcdDebugPropertyMask  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdDebugPropertyMask 2
#define _PCD_SIZE_PcdDebugPropertyMask 1
#define _PCD_GET_MODE_SIZE_PcdDebugPropertyMask _PCD_SIZE_PcdDebugPropertyMask
#define _PCD_TOKEN_PcdCanaryAllowRdtscFallback  0U
extern const BOOLEAN _gPcd_FixedAtBuild_PcdCanaryAllowRdtscFallback;
#define _PCD_GET_MODE_BOOL_PcdCanaryAllowRdtscFallback  _gPcd_FixedAtBuild_PcdCanaryAllowRdtscFallback
//#define _PCD_SET_MODE_BOOL_PcdCanaryAllowRdtscFallback  ASSERT(FALSE)  // It is not allowed to set value for a FIXED_AT_BUILD PCD
#define _PCD_VALUE_PcdCanaryAllowRdtscFallback 1
#define _PCD_SIZE_PcdCanaryAllowRdtscFallback 1
#define _PCD_GET_MODE_SIZE_PcdCanaryAllowRdtscFallback _PCD_SIZE_PcdCanaryAllowRdtscFallback


#ifdef __cplusplus
}
#endif

#endif
