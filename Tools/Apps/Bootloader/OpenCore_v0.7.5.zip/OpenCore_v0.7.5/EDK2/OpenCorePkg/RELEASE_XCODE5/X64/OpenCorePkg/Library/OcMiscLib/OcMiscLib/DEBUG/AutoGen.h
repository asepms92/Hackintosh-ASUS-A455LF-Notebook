/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_E9DF6F29_95AC_429A_8E42_FCE1F5B81148
#define _AUTOGENH_E9DF6F29_95AC_429A_8E42_FCE1F5B81148

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Protocols
extern GUID gEfiPciIoProtocolGuid;
extern GUID gEfiShellParametersProtocolGuid;
extern GUID gEfiLoadedImageProtocolGuid;
extern GUID gEfiSimpleFileSystemProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
