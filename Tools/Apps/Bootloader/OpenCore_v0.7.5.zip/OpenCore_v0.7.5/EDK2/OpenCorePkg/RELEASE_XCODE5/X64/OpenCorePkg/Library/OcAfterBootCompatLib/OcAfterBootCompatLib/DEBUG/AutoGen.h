/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_A393F7CF_3966_4C7E_8763_3DD991681C9B
#define _AUTOGENH_A393F7CF_3966_4C7E_8763_3DD991681C9B

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gAppleBootVariableGuid;

// Protocols
extern GUID gOcAfterBootCompatProtocolGuid;
extern GUID gOcFirmwareRuntimeProtocolGuid;
extern GUID gVMwareMacProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
