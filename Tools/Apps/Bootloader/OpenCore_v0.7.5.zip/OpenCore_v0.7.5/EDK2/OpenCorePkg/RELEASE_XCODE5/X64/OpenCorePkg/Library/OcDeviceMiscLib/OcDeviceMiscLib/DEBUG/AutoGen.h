/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_4CABEB89_2EBC_434A_84C5_E093FFD34174
#define _AUTOGENH_4CABEB89_2EBC_434A_84C5_E093FFD34174

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gEfiEventExitBootServicesGuid;
extern GUID gEfiEventVirtualAddressChangeGuid;

// Protocols
extern GUID gEfiPciIoProtocolGuid;
extern GUID gEfiDecompressProtocolGuid;
extern GUID gEfiLoadedImageProtocolGuid;
extern GUID gEfiDriverBindingProtocolGuid;
extern GUID gEfiDriverConfiguration2ProtocolGuid;
extern GUID gEfiDriverConfigurationProtocolGuid;
extern GUID gEfiDriverDiagnostics2ProtocolGuid;
extern GUID gEfiDriverDiagnosticsProtocolGuid;
extern GUID gEfiComponentName2ProtocolGuid;
extern GUID gEfiComponentNameProtocolGuid;
extern GUID gEfiDevicePathProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
