/**
  DO NOT EDIT
  FILE auto-generated
  Module name:
    AutoGen.h
  Abstract:       Auto-generated AutoGen.h for building module or library.
**/

#ifndef _AUTOGENH_0E93775E_0EDB_484E_A6E7_851F0580D450
#define _AUTOGENH_0E93775E_0EDB_484E_A6E7_851F0580D450

#ifdef __cplusplus
extern "C" {
#endif

#include <Base.h>

extern GUID  gEfiCallerIdGuid;
extern GUID  gEdkiiDscPlatformGuid;
extern CHAR8 *gEfiCallerBaseName;


// Guids
extern GUID gEfiProcessorSubClassGuid;
extern GUID gEfiMiscSubClassGuid;
extern GUID gApplePlatformProducerNameGuid;

// Protocols
extern GUID gEfiDataHubProtocolGuid;

// Definition of SkuId Array
extern UINT64 _gPcd_SkuId_Array[];


#ifdef __cplusplus
}
#endif

#endif
